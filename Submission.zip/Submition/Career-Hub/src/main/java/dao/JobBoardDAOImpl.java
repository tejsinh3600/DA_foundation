package dao;

import entity.*;
import exception.*;
import util.DBConnUtil;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class JobBoardDAOImpl implements IJobBoardDAO {

    @Override
    public void initializeDatabase() throws DatabaseConnectionException {
        try (Connection conn = DBConnUtil.getConnection()) {
            Statement stmt = conn.createStatement();
            stmt.execute("CREATE TABLE IF NOT EXISTS Companies (companyID INT PRIMARY KEY AUTO_INCREMENT, companyName VARCHAR(100), location VARCHAR(100))");
            stmt.execute("CREATE TABLE IF NOT EXISTS Jobs (jobID INT PRIMARY KEY AUTO_INCREMENT, companyID INT, jobTitle VARCHAR(100), jobDescription TEXT, jobLocation VARCHAR(100), salary DECIMAL(15,2), jobType VARCHAR(50), postedDate DATE, FOREIGN KEY (companyID) REFERENCES Companies(companyID))");
            stmt.execute("CREATE TABLE IF NOT EXISTS Applicants (applicantID INT PRIMARY KEY AUTO_INCREMENT, firstName VARCHAR(50), lastName VARCHAR(50), email VARCHAR(100), phone VARCHAR(20), resume VARCHAR(255))");
            stmt.execute("CREATE TABLE IF NOT EXISTS Applications (applicationID INT PRIMARY KEY AUTO_INCREMENT, jobID INT, applicantID INT, applicationDate DATE, coverLetter TEXT, FOREIGN KEY (jobID) REFERENCES Jobs(jobID), FOREIGN KEY (applicantID) REFERENCES Applicants(applicantID))");
        } catch (SQLException e) {
            throw new DatabaseConnectionException("Failed to initialize database: " + e.getMessage());
        }
    }

    @Override
    public void insertJobListing(JobListing job) throws DatabaseConnectionException {
        String sql = "INSERT INTO Jobs (companyID, jobTitle, jobDescription, jobLocation, salary, jobType, postedDate) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, job.getCompanyID());
            stmt.setString(2, job.getJobTitle());
            stmt.setString(3, job.getJobDescription());
            stmt.setString(4, job.getJobLocation());
            stmt.setDouble(5, job.getSalary());
            stmt.setString(6, job.getJobType());
            stmt.setDate(7, job.getPostedDate());
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseConnectionException("Failed to insert job listing: " + e.getMessage());
        }
    }

    @Override
    public void insertCompany(Company company) throws DatabaseConnectionException {
        String sql = "INSERT INTO Companies (companyName, location) VALUES (?, ?)";
        try (Connection conn = DBConnUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, company.getCompanyName());
            stmt.setString(2, company.getLocation());
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseConnectionException("Failed to insert company: " + e.getMessage());
        }
    }

    @Override
    public void insertApplicant(Applicant applicant) throws DatabaseConnectionException, InvalidEmailFormatException {
        if (!applicant.getEmail().matches("^[A-Za-z0-9+_.-]+@(.+)$")) {
            throw new InvalidEmailFormatException("Invalid email format: " + applicant.getEmail());
        }
        String sql = "INSERT INTO Applicants (firstName, lastName, email, phone, resume) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DBConnUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, applicant.getFirstName());
            stmt.setString(2, applicant.getLastName());
            stmt.setString(3, applicant.getEmail());
            stmt.setString(4, applicant.getPhone());
            stmt.setString(5, applicant.getResume());
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseConnectionException("Failed to insert applicant: " + e.getMessage());
        }
    }

    @Override
    public void insertJobApplication(JobApplication application) throws DatabaseConnectionException, ApplicationDeadlineException {
        String sqlCheck = "SELECT postedDate FROM Jobs WHERE jobID = ?";
        try (Connection conn = DBConnUtil.getConnection();
             PreparedStatement stmtCheck = conn.prepareStatement(sqlCheck)) {
            stmtCheck.setInt(1, application.getJobID());
            ResultSet rs = stmtCheck.executeQuery();
            if (rs.next()) {
                Date postedDate = rs.getDate("postedDate");
                LocalDate deadline = postedDate.toLocalDate().plusMonths(1); // Assume 1-month deadline
                if (application.getApplicationDate().toLocalDate().isAfter(deadline)) {
                    throw new ApplicationDeadlineException("Application deadline passed for job ID " + application.getJobID());
                }
            }
        } catch (SQLException e) {
            throw new DatabaseConnectionException("Failed to check job deadline: " + e.getMessage());
        }

        String sql = "INSERT INTO Applications (jobID, applicantID, applicationDate, coverLetter) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, application.getJobID());
            stmt.setInt(2, application.getApplicantID());
            stmt.setDate(3, application.getApplicationDate());
            stmt.setString(4, application.getCoverLetter());
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new DatabaseConnectionException("Failed to insert job application: " + e.getMessage());
        }
    }

    @Override
    public List<JobListing> getJobListings() throws DatabaseConnectionException {
        List<JobListing> jobs = new ArrayList<>();
        String sql = "SELECT * FROM Jobs";
        try (Connection conn = DBConnUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                jobs.add(new JobListing(
                        rs.getInt("jobID"), rs.getInt("companyID"), rs.getString("jobTitle"),
                        rs.getString("jobDescription"), rs.getString("jobLocation"), rs.getDouble("salary"),
                        rs.getString("jobType"), rs.getDate("postedDate")));
            }
        } catch (SQLException e) {
            throw new DatabaseConnectionException("Failed to retrieve job listings: " + e.getMessage());
        }
        return jobs;
    }

    @Override
    public List<Company> getCompanies() throws DatabaseConnectionException {
        List<Company> companies = new ArrayList<>();
        String sql = "SELECT * FROM Companies";
        try (Connection conn = DBConnUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                companies.add(new Company(
                        rs.getInt("companyID"), rs.getString("companyName"), rs.getString("location")));
            }
        } catch (SQLException e) {
            throw new DatabaseConnectionException("Failed to retrieve companies: " + e.getMessage());
        }
        return companies;
    }

    @Override
    public List<Applicant> getApplicants() throws DatabaseConnectionException {
        List<Applicant> applicants = new ArrayList<>();
        String sql = "SELECT * FROM Applicants";
        try (Connection conn = DBConnUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                applicants.add(new Applicant(
                        rs.getInt("applicantID"), rs.getString("firstName"), rs.getString("lastName"),
                        rs.getString("email"), rs.getString("phone"), rs.getString("resume")));
            }
        } catch (SQLException e) {
            throw new DatabaseConnectionException("Failed to retrieve applicants: " + e.getMessage());
        }
        return applicants;
    }

    @Override
    public List<JobApplication> getApplicationsForJob(int jobID) throws DatabaseConnectionException {
        List<JobApplication> applications = new ArrayList<>();
        String sql = "SELECT * FROM Applications WHERE jobID = ?";
        try (Connection conn = DBConnUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, jobID);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                applications.add(new JobApplication(
                        rs.getInt("applicationID"), rs.getInt("jobID"), rs.getInt("applicantID"),
                        rs.getDate("applicationDate"), rs.getString("coverLetter")));
            }
        } catch (SQLException e) {
            throw new DatabaseConnectionException("Failed to retrieve applications: " + e.getMessage());
        }
        return applications;
    }

    @Override
    public double calculateAverageSalary() throws DatabaseConnectionException, NegativeSalaryException {
        String sql = "SELECT salary FROM Jobs";
        double totalSalary = 0;
        int count = 0;
        try (Connection conn = DBConnUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                double salary = rs.getDouble("salary");
                if (salary < 0) {
                    throw new NegativeSalaryException("Negative salary found in job listing");
                }
                totalSalary += salary;
                count++;
            }
            return count > 0 ? totalSalary / count : 0;
        } catch (SQLException e) {
            throw new DatabaseConnectionException("Failed to calculate average salary: " + e.getMessage());
        }
    }

    @Override
    public List<JobListing> getJobsBySalaryRange(double minSalary, double maxSalary) throws DatabaseConnectionException {
        List<JobListing> jobs = new ArrayList<>();
        String sql = "SELECT * FROM Jobs WHERE salary BETWEEN ? AND ?";
        try (Connection conn = DBConnUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setDouble(1, minSalary);
            stmt.setDouble(2, maxSalary);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                jobs.add(new JobListing(
                        rs.getInt("jobID"), rs.getInt("companyID"), rs.getString("jobTitle"),
                        rs.getString("jobDescription"), rs.getString("jobLocation"), rs.getDouble("salary"),
                        rs.getString("jobType"), rs.getDate("postedDate")));
            }
        } catch (SQLException e) {
            throw new DatabaseConnectionException("Failed to retrieve jobs by salary range: " + e.getMessage());
        }
        return jobs;
    }
}

