package com.carrental;

import com.carrental.dao.ICarLeaseRepository;
import com.carrental.dao.ICarLeaseRepositoryImpl;
import com.carrental.entity.Vehicle;
import com.carrental.exception.CarNotFoundException;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class CarRentalTest {
    private ICarLeaseRepository repo;

    @Before
    public void setUp() {
        repo = new ICarLeaseRepositoryImpl();
    }

    @Test
    public void testAddCar() {
        Vehicle vehicle = new Vehicle(0, "Toyota", "Camry", 2023, 50.0, "available", 5, 2.5);
        repo.addCar(vehicle);
        assertTrue(repo.listAvailableCars().stream().anyMatch(v -> v.getModel().equals("Camry")));
    }

    @Test(expected = CarNotFoundException.class)
    public void testFindCarByIdNotFound() throws CarNotFoundException {
        repo.findCarById(999); // Assuming 999 doesn't exist
    }
}