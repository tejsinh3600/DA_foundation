package com.carrental.main;

import com.carrental.dao.ICarLeaseRepository;
import com.carrental.dao.ICarLeaseRepositoryImpl;
import com.carrental.entity.*;
import com.carrental.exception.*;

import java.sql.Date;
import java.util.List;
import java.util.Scanner;

public class CarRentalApp {
    private static final Scanner scanner = new Scanner(System.in);
    private static final ICarLeaseRepository repo = new ICarLeaseRepositoryImpl();

    public static void main(String[] args) {
        while (true) {
            displayMenu();
            int choice = getIntInput("Choose an option: ");
            try {
                switch (choice) {
                    case 1: addCustomer(); break;
                    case 2: viewCustomers(); break;
                    case 3: createLease(); break;
                    case 4: viewLeases(); break;
                    case 5: makePayment(); break;
                    case 6: viewPayments(); break;
                    case 7: addVehicle(); break;
                    case 8: viewVehicles(); break;
                    case 9: updateVehicleAvailability(); break;
                    case 10: returnCar(); break;
                    case 11: System.out.println("Exiting system. Thank you!"); return;
                    default: System.out.println("Invalid choice! Please try again.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    private static void displayMenu() { 
        System.out.println("\n===== Car Rental System =====");
        System.out.println("1. Add Customer");
        System.out.println("2. View Customers");
        System.out.println("3. Create Lease");
        System.out.println("4. View Leases");
        System.out.println("5. Make Payment");
        System.out.println("6. View Payments");
        System.out.println("7. Add Vehicle");
        System.out.println("8. View Vehicles");
        System.out.println("9. Update Vehicle Availability");
        System.out.println("10. Return Car");
        System.out.println("11. Exit");
    }

    private static int getIntInput(String prompt) {
        System.out.print(prompt);
        while (!scanner.hasNextInt()) {
            System.out.println("Invalid input. Please enter a number.");
            scanner.next();
            System.out.print(prompt);
        }
        int value = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        return value;
    }

    private static String getStringInput(String prompt) {
        System.out.print(prompt);
        return scanner.nextLine();
    }

    private static void addCustomer() {
        String firstName = getStringInput("Enter First Name: ");
        String lastName = getStringInput("Enter Last Name: ");
        String email = getStringInput("Enter Email: ");
        String phoneNumber = getStringInput("Enter Phone Number: ");
        Customer customer = new Customer(0, firstName, lastName, email, phoneNumber);
        repo.addCustomer(customer);
    }

    private static void viewCustomers() {
        List<Customer> customers = repo.listCustomers();
        System.out.println("\n===== Customers =====");
        if (customers.isEmpty()) {
            System.out.println("No customers found.");
        } else {
            for (Customer c : customers) {
                System.out.println("ID: " + c.getCustomerID() + " | Name: " + c.getFirstName() + " " + c.getLastName() +
                        " | Email: " + c.getEmail() + " | Phone: " + c.getPhoneNumber());
            }
        }
    }

    private static void createLease() throws CarNotFoundException, CustomerNotFoundException {
        int customerID = getIntInput("Enter Customer ID: ");
        int vehicleID = getIntInput("Enter Vehicle ID: ");
        String startDateStr = getStringInput("Enter Start Date (YYYY-MM-DD): ");
        String endDateStr = getStringInput("Enter End Date (YYYY-MM-DD): ");
        String type = getStringInput("Enter Lease Type (DailyLease/MonthlyLease): ");
        try {
            Lease lease = repo.createLease(customerID, vehicleID, Date.valueOf(startDateStr), Date.valueOf(endDateStr), type);
            System.out.println("Lease created with ID: " + lease.getLeaseID());
        } catch (IllegalArgumentException e) {
            System.out.println("Invalid date format. Use YYYY-MM-DD.");
        }
    }

    private static void viewLeases() {
        List<Lease> leases = repo.listLeaseHistory();
        System.out.println("\n===== Leases =====");
        if (leases.isEmpty()) {
            System.out.println("No leases found.");
        } else {
            for (Lease l : leases) {
                System.out.println("Lease ID: " + l.getLeaseID() + " | Vehicle ID: " + l.getVehicleID() +
                        " | Customer ID: " + l.getCustomerID() + " | Start Date: " + l.getStartDate() +
                        " | End Date: " + l.getEndDate() + " | Type: " + l.getType());
            }
        }
    }

    private static void makePayment() throws LeaseNotFoundException {
        int leaseID = getIntInput("Enter Lease ID: ");
        double amount = getDoubleInput("Enter Payment Amount: ");
        Lease lease = new Lease();
        lease.setLeaseID(leaseID);
        repo.recordPayment(lease, amount);
    }

    private static double getDoubleInput(String prompt) {
        System.out.print(prompt);
        while (!scanner.hasNextDouble()) {
            System.out.println("Invalid input. Please enter a valid amount.");
            scanner.next();
            System.out.print(prompt);
        }
        double value = scanner.nextDouble();
        scanner.nextLine(); // Consume newline
        return value;
    }

    private static void viewPayments() {
        List<Payment> payments = repo.listPayments();
        System.out.println("\n===== Payments =====");
        if (payments.isEmpty()) {
            System.out.println("No payments found.");
        } else {
            for (Payment p : payments) {
                System.out.println("Payment ID: " + p.getPaymentID() + " | Lease ID: " + p.getLeaseID() +
                        " | Date: " + p.getPaymentDate() + " | Amount: $" + p.getAmount());
            }
        }
    }

    private static void addVehicle() {
        String make = getStringInput("Enter Make: ");
        String model = getStringInput("Enter Model: ");
        int year = getIntInput("Enter Year: ");
        double dailyRate = getDoubleInput("Enter Daily Rate: ");
        String status = getStringInput("Enter Availability Status (available/notAvailable): ");
        int seats = getIntInput("Enter Seating Capacity: ");
        double engineCapacity = getDoubleInput("Enter Engine Capacity: ");
        Vehicle vehicle = new Vehicle(0, make, model, year, dailyRate, status, seats, engineCapacity);
        repo.addCar(vehicle);
    }

    private static void viewVehicles() {
        List<Vehicle> vehicles = repo.listAvailableCars();
        System.out.println("\n===== Available Vehicles =====");
        if (vehicles.isEmpty()) {
            System.out.println("No available vehicles found.");
        } else {
            for (Vehicle v : vehicles) {
                System.out.println("ID: " + v.getVehicleID() + " | " + v.getMake() + " " + v.getModel() +
                        " | Year: " + v.getYear() + " | Rate: $" + v.getDailyRate() + "/day" +
                        " | Status: " + v.getStatus());
            }
        }
    }

    private static void updateVehicleAvailability() throws CarNotFoundException {
        int vehicleID = getIntInput("Enter Vehicle ID: ");
        String status = getStringInput("Enter new status (available/notAvailable): ");
        repo.updateVehicleStatus(vehicleID, status);
    }

    private static void returnCar() throws LeaseNotFoundException {
        int leaseID = getIntInput("Enter Lease ID: ");
        repo.returnCar(leaseID);
    }
}